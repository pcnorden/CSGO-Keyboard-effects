DISCLAIMER: THIS IS A ALPHA SOFTWARE, THERE WILL BE UPDATES IN THE FUTURE, BUT RIGHT NOW IT MIGHT CRASH DUE TO ERRORS, IF SO, PLEASE REPORT THE ERROR!

IMPORTANT: The folders "x86" and "x64" with the files inside NEED to be in the same folder as the .exe file, or else the program just crashes. Nobody likes crashing, do we?

This is a software made in C#, that gets data from CS:GO, parses it, then uses the SDK for Corsair Effects Engine, and displays colors there.
The software uses an object called "HttpListener" that needs admin privilieges to run, and when it runs, the software listens to port 3000 after JSON-data sent with a POST.

This project is open-source for all those modders out there that knows how to program on my github page (https://github.com/pcnorden/CSGO-Keyboard-effects)

I am not responsible for any damage on your computer, especially if hardware fails when running this software!

Ways to reach me if you would like to contact me:

* www.reddit.com/user/pcnorden (I spend most of my time on reddit)

* twitter @pcnorden (I have a bot rigged to check every 24 hours, so I might be a bit late in the responses)

That's it, and thanks for me!

(Copyright stuff...)

Copyright (c) 2016 pcnorden

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.